function f41(){
	/* x est le bouton */
	x=document.getElementById("bt");
	
	/* y est l'élément paragraphe */
	y=document.getElementById("intro");
	
	/* z est le formulaire */
	z=document.getElementById("formGr");
	
	if(x.value=="Cacher"){
		x.value="Afficher";
		x.style.color="blue";
		z.style.visibility = "hidden";
		y.innerHTML ="Formulaire caché"

	}
	else{
		x.value="Cacher";
		x.style.color="red";
		z.style.visibility="visible";
		y.innerHTML ="Formulaire visible"
	}
};

function f42(){
		var mylist=document.getElementById("myList");
		var zonetexte = document.getElementById("groupe")
		zonetexte.value = mylist.options[mylist.selectedIndex].text;
}
	
function f43(){
	var ele = document.getElementById("navpara")
	for(x in navigator)
		ele.innerHTML+= "<h4>"+x+" -- "+navigator[x]+"<\h4>"
}
